__reduce__()
----------------------------------------------------------------------

Return pickle-able data for this automaton instance.
