**pyahocorasick** is a fast and memory efficient library for exact or
approximate multi-pattern string search meaning that you can find multiple
key strings occurrences at once in some input text.
