values([prefix, [wildcard, [how]]])
----------------------------------------------------------------------

Return an iterator on values associated with each keys.
Keys are matched optionally to the prefix using the same logic
and arguments as in the keys() method.
