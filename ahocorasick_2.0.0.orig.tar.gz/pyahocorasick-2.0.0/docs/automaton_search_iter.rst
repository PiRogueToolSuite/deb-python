This class is not available directly but instances of AutomatonSearchIter
are returned by the iter() method of an Automaton. This iterator can be
manipulated through its set() method.
